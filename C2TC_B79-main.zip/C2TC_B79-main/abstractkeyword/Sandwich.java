package org.tnsif.abstractkeyword;

abstract public class Sandwich {
	
	void showRecipe()
	{
		System.out.println("I don't know how to " + "prepare Sandwitch ");
	}
	
	abstract void prepare();

}
