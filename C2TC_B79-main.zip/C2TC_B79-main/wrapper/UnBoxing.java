package org.tnsif.wrapperclass;
//Program to demonstrate on Unboxing
//Unboxing: Conversion of object type to the primitive datatypes
public class UnBoxing {

	public static void main(String[] args) {
		Character ch='s';
		//Conversion of object type to primitive
		char c=ch;
		System.out.println(c);
		

	}

}
