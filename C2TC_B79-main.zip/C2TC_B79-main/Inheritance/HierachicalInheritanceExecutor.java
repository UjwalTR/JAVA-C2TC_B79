//Driver class 
//Hierachical Inheritance Executor
package org.tnsif.hierachicalinheritance;

public class HierachicalInheritanceExecutor {

	public static void main(String[] args) {
		
		Tiramisu t= new Tiramisu("Realme", "DoubleSlot", 13);
		SnowCone s= new SnowCone("Samsung", "DoubleSlot", 12);
		System.out.println(t);
		System.out.println(s);
		
	}

}
