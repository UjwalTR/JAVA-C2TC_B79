package org.tnsif.finalkeyword;

public class FinalKeywordExecutor {

	public static void main(String[] args) {
		FinalKeyword fk = new FinalKeyword();
		fk.print();
		//fk.Salary=34700.84;

	}

}
