package org.tnsif.finalkeyword;

public class MethodExecutor {

	public static void main(String[] args) {
		HP hp = new HP();
		hp.display();
		hp.display(hp.processor);

	}

}
