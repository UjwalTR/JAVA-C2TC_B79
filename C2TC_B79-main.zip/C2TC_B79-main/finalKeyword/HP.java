package org.tnsif.finalkeyword;

public class HP extends Laptop{
	final String processor = "Intel I7";
	
	/*void display()
	{
		System.out.println("Processor: "+processor);
	}*/
	
	void display(String processor)
	{
		System.out.println("Processor: "+processor);
	}

}
